# InfraredTargetDectectionFKRW

The demo for the paper "Infrared Small Target Detection Based on Facet Kernel and Random Walker" published on TGRS.

Note that the code is based on the "Graph Analysis Toolbox"" of L. Grady.

If you use this code, please kindly cite our paper:

Y. Qin, B. Lorenzo, C. Gao, B. Li, "Infrared Small Target Detection Based on Facet Kernel and Random Walker", IEEE Transactions on Geoscience and Remote Sensing, 2019, DOI:10.1109/TGRS.2019.2911513 
